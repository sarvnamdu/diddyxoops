//InvalidCredit.java
package bank;

// Custom exception for invalid credit transactions
public class InvalidCredit extends Exception {
    public InvalidCredit() {
        System.out.println("Invalid credit amount."); // Exception message
    }
}
