//Customer.java
package bank;

import java.util.Scanner;

// Class to represent a bank customer
public class Customer {
    String name;  // Customer name
    int accNo;    // Customer account number
    int balance;  // Customer account balance

    // Constructor to initialize customer details
    public Customer(String name, int accNo) {
        this.name = name;
        this.accNo = accNo;
        this.balance = 0; // Initial balance is set to 0
    }

    // Method to handle credit transactions
    public void creditTransaction(int amount) {
        Scanner input = new Scanner(System.in);
        try {
            // Check if the credit amount is valid
            if (amount < 0) {
                throw new InvalidCredit(); // Throw exception for invalid credit
            } else {
                balance += amount; // Add amount to balance if valid
            }
        } catch (InvalidCredit e) {
            System.out.println("\nPlease enter a valid credit amount:");
            amount = input.nextInt();
            creditTransaction(amount); // Retry credit transaction with valid input
        }
    }

    // Method to handle debit transactions
    public void debitTransaction(int amount) {
        Scanner input = new Scanner(System.in);
        try {
            // Check if the debit amount is valid
            if (amount > balance) {
                throw new InvalidDebit(); // Throw exception for invalid debit
            } else {
                balance -= amount; // Deduct amount from balance if valid
            }
        } catch (InvalidDebit e) {
            System.out.println("\nPlease enter a valid debit amount:");
            amount = input.nextInt();
            debitTransaction(amount); // Retry debit transaction with valid input
        }
    }

    // Method to display customer details
    public void displayDetails() {
        System.out.println("\nCustomer Details");
        System.out.println("****************");
        System.out.println("Customer Name: " + this.name);
        System.out.println("Customer Account Number: " + this.accNo);
        System.out.println("Customer Current Balance: " + this.balance);
    }
}
