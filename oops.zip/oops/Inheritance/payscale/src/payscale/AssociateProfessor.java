/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payscale;

//Associate Professor
public class AssociateProfessor extends Employee {
 public AssociateProfessor() {
 super();
 computeAssociateProfessorPay();
 }
 public void computeAssociateProfessorPay() {
 System.out.print("Enter Basic Pay for Associate Professor [Default = 40000]:");
 this.basic_pay = input.nextInt();
 if (this.basic_pay == -1) {
 this.basic_pay = 40000;
 System.out.println("Default Pay Taken");
 }
 computeCurrentBasicPay("Associate Professor");
 generatePaySlip();
 displayPaySlip();
 }
}
