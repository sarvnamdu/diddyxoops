/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payscale;
//Main.java
import payscale.AssistantProfessor;
import payscale.AssociateProfessor;
import payscale.Programmer;
import payscale.Professor;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
public class Main {
 public static void main(String[] args) throws IOException {
 BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
 int choice = 0;
 while (choice != 5) {
 System.out.println("\n\nEmployee Payroll System");
 System.out.println("************************");
 System.out.println("1. Programmer");
 System.out.println("2. Assistant Professor");
 System.out.println("3. Associate Professor");
 System.out.println("4. Professor");
 System.out.println("5. Exit");
 System.out.print("Enter Your Choice: ");
 try {
 choice = Integer.parseInt(reader.readLine());
 } catch (NumberFormatException e) {
 System.out.println("Invalid input! Please enter a number between 1 and 5 ");
 continue;
 }
 switch (choice) {
 case 1:
 System.out.println("Programmer Selected");
 new Programmer();
 break;
 case 2:
 System.out.println("Assistant Professor Selected");
 new AssistantProfessor();
 break;
 case 3:
 System.out.println("Associate Professor Selected");
 new AssociateProfessor();
 break;
 case 4:
 System.out.println("Professor Selected");
 new Professor();
 break;
 case 5:
 System.out.println("Thank You for using the Payroll System!");
 break;
 default:
 System.out.println("Enter a valid choice!");
 break;
 }
 }
 reader.close();
 }
}
