/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payscale;
//Programmer.java
public class Programmer extends Employee {
 public Programmer() {
 super();
 computeProgrammerPay();
 }
 public void computeProgrammerPay() {
 System.out.print("Enter Basic Pay for Programmer [Default = 30000]: ");
 this.basic_pay = input.nextInt();
 if (this.basic_pay == -1) {
 this.basic_pay = 30000;
 System.out.println("Default Pay Taken");
 }
 computeCurrentBasicPay("Programmer");
 generatePaySlip();
 displayPaySlip();
 }
}
