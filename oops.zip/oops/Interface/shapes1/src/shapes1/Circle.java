//Circle.java
package shapes1;
import java.util.Scanner;

public class Circle implements shape {
    double radius = 0.0;
    double area = 0.0;

    
    public void printArea() {
        System.out.println("\nCircle");
        System.out.println("----------------------");
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Radius of Circle: ");
        this.radius = input.nextDouble();
        this.area = Math.PI * this.radius * this.radius;
        System.out.println("Area of the Circle is: " + this.area);
    }
}
