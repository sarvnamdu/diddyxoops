// File Name: UserFileHandler.java
package files;

import java.io.File;

public class UserFileHandler {
    File aFile; // File object to represent the file
    boolean isReadable = false; // Flag to check if file is readable
    boolean isWritable = false; // Flag to check if file is writable
    boolean isExists = false; // Flag to check if file exists
    int length = 0; // To store the length of the file in bytes

    // Constructor to initialize the file object and check its properties
    public UserFileHandler(String path) {
        aFile = new File(path); // Create a new File object with the given path
        this.isExists = aFile.exists(); // Check if the file exists
        this.isReadable = aFile.canRead(); // Check if the file is readable
        this.isWritable = aFile.canWrite(); // Check if the file is writable
        this.length = (int) aFile.length(); // Get the file's length in bytes
    }

    // Method to display the file details
    public void fileDetails() {
        if (isExists) { // If the file exists, display its details
            System.out.println("The File " + aFile.getName() + " is Available at: " + aFile.getParent());

            // Check if the file is readable and writable, and display the appropriate message
            if (isReadable && isWritable)
                System.out.println("File is Readable and Writable");
            else if (isReadable)
                System.out.println("File is Only Readable");
            else if (isWritable)
                System.out.println("File is Only Writable");

            // Display the total length of the file
            System.out.println("Total length of the file is: " + this.length + " bytes");
        } else { // If the file does not exist
            System.out.println("File does not exist.");
        }
    }
}
