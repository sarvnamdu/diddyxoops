// File Name: Main.java
import java.util.Scanner;
import files.UserFileHandler; // Importing the UserFileHandler class

public class Main {
    public static void main(String[] args) {
        String filePath; // To store the file path input by the user
        Scanner input = new Scanner(System.in); // Scanner to read user input

        // Display the program's title
        System.out.println("File Handler");
        System.out.println("************");

        // Prompt the user to enter the file path
        System.out.println("Enter the file path:");
        filePath = input.next(); // Read the file path input

        // Create a new instance of UserFileHandler and display file details
        new UserFileHandler(filePath).fileDetails();
        input.close(); // Close the scanner
    }
}
