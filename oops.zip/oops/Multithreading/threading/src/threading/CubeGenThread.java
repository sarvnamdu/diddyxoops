// File Name: CubeGenThread.java
package threading;

// Thread to calculate the cube of a number
public class CubeGenThread extends Thread {
    int number; // The number for which the cube is calculated
    int cube;   // The calculated cube

    // Constructor to initialize the number
    public CubeGenThread(int number) {
        this.number = number;
    }

    @Override
    public void run() {
        try {
            // Sleep for 2 seconds to simulate processing
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println("CubeGenThread interrupted");
        }
        // Calculate the cube of the number
        this.cube = this.number * this.number * this.number;
        System.out.println("CubeGenThread --> Cube of " + number + " is " + cube);
    }
}
