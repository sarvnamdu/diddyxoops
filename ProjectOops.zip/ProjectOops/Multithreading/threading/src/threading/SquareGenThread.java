// File Name: SquareGenThread.java
package threading;

// Thread to calculate the square of a number
public class SquareGenThread extends Thread {
    int number; // The number for which the square is calculated
    int square; // The calculated square

    // Constructor to initialize the number
    public SquareGenThread(int number) {
        this.number = number;
    }

    @Override
    public void run() {
        try {
            // Sleep for 3 seconds to simulate processing
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.out.println("SquareGenThread interrupted");
        }
        // Calculate the square of the number
        this.square = this.number * this.number;
        System.out.println("SquareGenThread --> Square of " + number + " is " + square);
    }
}
