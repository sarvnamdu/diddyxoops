// File Name: RandomNumberThread.java
package threading;

import java.util.Random;

// Thread to generate random numbers continuously
public class RandomNumberThread extends Thread {
    Random num = new Random(); // Random number generator
    int value;

    @Override
    public void run() {
        while (true) {
            try {
                // Sleep for 1 second between generating numbers
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println("RandomNumberThread interrupted");
            }

            // Generate a random number between 0 and 999
            value = num.nextInt(1000);
            System.out.println("RandomNumberThread generated a number: " + value);

            // Start a new thread based on whether the number is even or odd
            if (value % 2 == 0) {
                // Start SquareGenThread if the number is even
                new SquareGenThread(value).start();
            } else {
                // Start CubeGenThread if the number is odd
                new CubeGenThread(value).start();
            }
        }
    }
}
