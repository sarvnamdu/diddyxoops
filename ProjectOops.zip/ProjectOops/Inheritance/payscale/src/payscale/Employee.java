/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payscale;

//Employee.java
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
class Employee {
 String emp_name, emp_id, emp_address, emp_mail_id, emp_mobile_no;
 int basic_pay, per_day_pay, current_basic_pay;
 int da, hra, pf, gross_pay, net_pay;
 int no_of_days_in_current_month, no_of_days_worked;
 Calendar cal;
 Scanner input;
 Employee() {
 input = new Scanner(System.in);
 cal = new GregorianCalendar();
 no_of_days_in_current_month = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
 getUserBasicDetails();
 }
 public void generatePaySlip() {
 this.da = (this.current_basic_pay * 97) / 100;
 this.hra = (this.current_basic_pay * 12) / 100;
 this.pf = (this.current_basic_pay * 10) / 100;
 this.gross_pay = this.current_basic_pay + da + hra;
 this.net_pay = gross_pay - pf;
 }
 public void displayPaySlip() {
 System.out.println("Name: " + this.emp_name);
 System.out.println("ID: " + this.emp_id);
 System.out.println("Address: " + this.emp_address);
 System.out.println("Mail ID: " + this.emp_mail_id);
 System.out.println("Mobile No: " + this.emp_mobile_no);
 System.out.println("\nEarnings:");
 System.out.println("BASIC Pay: " + current_basic_pay + " Rs");
 System.out.println("DA: " + da + " Rs");
 System.out.println("HRA: " + hra + " Rs");
 System.out.println("\nDeductions:");
 System.out.println("PF: " + pf + " Rs");
 System.out.println("\nPay Details:");
 System.out.println("GROSS Pay: " + gross_pay + " Rs");
 System.out.println("NET Pay: " + net_pay + " Rs");
 }
 public void getUserBasicDetails() {
 System.out.println("Enter Employee Details:");
 System.out.print("Name: ");
 this.emp_name = input.nextLine();
 System.out.print("ID: ");
 this.emp_id = input.nextLine();
 System.out.print("Address: ");
 this.emp_address = input.nextLine();
 System.out.print("Mail ID: ");
 this.emp_mail_id = input.nextLine();
 System.out.print("Mobile No: ");
 this.emp_mobile_no = input.nextLine();
 }
 public void computeCurrentBasicPay(String empType) {
 this.per_day_pay = this.basic_pay / no_of_days_in_current_month;
 System.out.println("\nBasic Pay of " + empType + ": " + this.basic_pay + "Rs");
 System.out.println("Pay Per Day: " + this.per_day_pay + " Rs");
 System.out.print("Enter number of days worked (excluding LWP): ");
 this.no_of_days_worked = input.nextInt();
 if (no_of_days_worked <= no_of_days_in_current_month) {
 this.current_basic_pay = this.per_day_pay * no_of_days_worked;
 } else {
 System.out.println("Invalid input for days worked. Please restart.");
 System.exit(0);
 }
 }
}
