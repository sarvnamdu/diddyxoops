//Shape.java
package shapes1;

public interface shape {
    void printArea();
}
