//InvalidDebit.java
package bank;

// Custom exception for invalid debit transactions
public class InvalidDebit extends Exception {
    public InvalidDebit() {
        System.out.println("Invalid debit amount."); // Exception message
    }
}
