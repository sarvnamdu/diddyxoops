/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

//Main.java

import java.util.Scanner;
import bank.*;

// Main class to execute bank operations
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Variables to store user inputs for customer details
        String name;
        int accNo;

        // Prompt user to enter customer details
        System.out.println("Enter Customer Name:");
        name = input.next();
        System.out.println("Enter Account Number:");
        accNo = input.nextInt();

        // Create a Customer object
        Customer aCustomer = new Customer(name, accNo);

        // Variable to store the user's menu choice
        int choice = 0;

        // Loop until the user chooses to exit
        while (choice != 4) {
            System.out.println("\n1. Add Money\n2. Get Money\n3. Details\n4. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            // Execute operations based on user's choice
            switch (choice) {
                case 1:
                    // Add money to the account
                    System.out.println("Enter the amount to credit:");
                    aCustomer.creditTransaction(input.nextInt());
                    break;
                case 2:
                    // Deduct money from the account
                    System.out.println("Enter the amount to debit:");
                    aCustomer.debitTransaction(input.nextInt());
                    break;
                case 3:
                    // Display customer details
                    aCustomer.displayDetails();
                    break;
                case 4:
                    // Exit the program
                    System.out.println("Thank You!!!");
                    break;
                default:
                    // Handle invalid menu choice
                    System.out.println("Invalid choice! Please try again.");
            }
        }

        // Close the scanner to prevent resource leaks
        input.close();
    }
}
