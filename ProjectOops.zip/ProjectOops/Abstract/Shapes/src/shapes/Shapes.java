
package shapes;


public abstract class Shapes {
    double length = 0.0;
    double height = 0.0;

    public abstract void printArea();
}
